"""
Agentic Resume Screening Assistant

A multi-agent system for automated resume screening with human-in-the-loop review.
"""

__version__ = "1.0.0"
__author__ = "Resume Screening Team"
